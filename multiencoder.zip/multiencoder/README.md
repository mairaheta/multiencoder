# Encoder Microservice

Service to encode a text in MorseCode and other Codifications and show the result in the console. 

### Notes:
-The Codification list can grow, so we use the Observer pattern for adding the new codifications.


### Documentation:
Request: http://localhost:8025/encoder/{texto a codificar}
