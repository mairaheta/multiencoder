package com.example.multiencoder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultiencoderApplication{

	public static void main(String[] args) {

		SpringApplication.run(MultiencoderApplication.class, args);
	}

}
