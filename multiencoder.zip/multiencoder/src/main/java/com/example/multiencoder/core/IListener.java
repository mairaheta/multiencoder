package com.example.multiencoder.core;

import com.example.multiencoder.exceptions.NotifyException;

public interface IListener<T> {
    void notify (T data) throws NotifyException;
}
