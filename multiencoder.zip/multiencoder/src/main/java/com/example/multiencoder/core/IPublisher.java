package com.example.multiencoder.core;

public interface IPublisher<T> {
    void registerListener(IListener<T> listener);
    void unregisterListener(IListener<T> listener);
    void notifyAllListener(T data);
}
