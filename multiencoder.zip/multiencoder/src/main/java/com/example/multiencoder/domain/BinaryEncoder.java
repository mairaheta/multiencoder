package com.example.multiencoder.domain;

import org.springframework.stereotype.Service;

@Service("Binary")
public class BinaryEncoder implements Encoder {

    @Override
    public void encode(String text) {

    }
}
