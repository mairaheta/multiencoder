package com.example.multiencoder.core;

import com.example.multiencoder.exceptions.NotifyException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class EncoderPublisher<T> implements IPublisher<T> {

    private List<IListener<T>> listeners = new ArrayList<>();

    @Override
    public void registerListener(IListener<T> newlistener) {
        listeners.add(newlistener);
    }

    @Override
    public void unregisterListener(IListener<T> oldlistener) {
        listeners.remove(oldlistener);
    }

    @Override
    public void notifyAllListener(T notificationData) {

        for (IListener<T> listener : listeners)
        {
            try
            {
                listener.notify(notificationData);
            } catch (NotifyException e)
            {
                log.info("Error Notifying -> {}",e.getMessage());
            }
            catch (Exception e)
            {
                log.error("Error -> {}",e.getMessage(),e);
            }
        }
    }
}
