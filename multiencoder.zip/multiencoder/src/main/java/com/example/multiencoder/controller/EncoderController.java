package com.example.multiencoder.controller;

import com.example.multiencoder.core.IPublisher;
import com.example.multiencoder.domain.Encoder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EncoderController {

    @Autowired IPublisher<String> publisher;
    private Encoder encoder;

    public EncoderController(@Qualifier("MorseCode") Encoder encoder) {
        this.encoder = encoder;
    }

    @GetMapping("/encoder/{text}")
    public String getGreetings(@PathVariable("text") String text)
    {
        encoder.encode(text);

        //Adding new encoders
        publisher.notifyAllListener(text);

        return "Encoding Result of " + text + ", See console...!!!";
    }
}
