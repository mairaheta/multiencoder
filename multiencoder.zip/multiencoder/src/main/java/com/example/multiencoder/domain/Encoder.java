package com.example.multiencoder.domain;

public interface Encoder {
    void encode(String text);
}
