package com.example.multiencoder.exceptions;

public class NotifyException extends Exception {
    private static final long serialVersionUID = 1L;

    public NotifyException(String message) throws NotifyException{
        super(message);
    }
}
