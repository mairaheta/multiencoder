package com.example.multiencoder.domain;


public interface ICodificationRepository {
    String getCode (String c);
}
