package com.example.multiencoder.core;

import com.example.multiencoder.domain.Encoder;
import com.example.multiencoder.exceptions.NotifyException;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class BatListener implements IListener<String> {

    private Encoder encoder;

    public BatListener(@Qualifier("Bat") Encoder encoder) {
        this.encoder = encoder;
    }

    @Override
    public void notify(String data) throws NotifyException {

        encoder.encode(data);

    }
}
