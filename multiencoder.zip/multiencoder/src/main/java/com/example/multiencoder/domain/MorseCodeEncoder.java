package com.example.multiencoder.domain;

import org.springframework.stereotype.Service;

@Service("MorseCode")
public class MorseCodeEncoder implements Encoder {

    @Override
    public void encode(String text) {

        

    }
}
