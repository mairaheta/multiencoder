package com.example.multiencoder.model;

public enum Morse {
    A("\".-\"");

    private final String value;

    Morse(String v) {
        this.value = v;
    }

    public String value() {
        return value;
    }
}
