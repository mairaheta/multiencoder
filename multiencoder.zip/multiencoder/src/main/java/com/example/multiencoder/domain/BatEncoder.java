package com.example.multiencoder.domain;

import org.springframework.stereotype.Service;

@Service("Bat")
public class BatEncoder implements Encoder {

    @Override
    public void encode(String text) {

    }
}
