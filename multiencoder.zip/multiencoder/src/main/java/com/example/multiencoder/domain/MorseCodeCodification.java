package com.example.multiencoder.domain;

import org.springframework.stereotype.Service;

@Service("MCCodification")
public class MorseCodeCodification implements ICodificationRepository {

    @Override
    public String getCode(String c) {




        return null;
    }
}
