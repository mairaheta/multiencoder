package com.example.multiencoder;

import com.example.multiencoder.core.BatListener;
import com.example.multiencoder.core.BinaryListener;
import com.example.multiencoder.core.EncoderPublisher;
import com.example.multiencoder.core.IListener;
import com.example.multiencoder.domain.BinaryEncoder;
import com.example.multiencoder.domain.Encoder;
import com.example.multiencoder.exceptions.NotifyException;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import static org.mockito.Mockito.verify;

@SpringBootTest
class MultiencoderApplicationTests {

	@Test
	void contextLoads() {
	}

	@Test
	public void PublisherSuccessTest() throws NotifyException
	{
		IListener<String> listener = Mockito.mock(BinaryListener.class);

		EncoderPublisher<String> publisher = new EncoderPublisher<>() ;

		publisher.registerListener(listener);
		publisher.notifyAllListener("Hello");
		publisher.unregisterListener(listener);

		verify(listener).notify(Mockito.any());

	}


	@Test
	public void ListenerSuccessTest() throws NotifyException {

		Encoder encoder = Mockito.mock(BinaryEncoder.class);
		IListener listener = new BatListener(encoder);
		listener.notify("hello");

		verify(encoder).encode(Mockito.any());

	}

}
